from app.ui_gui import launch_gui

if __name__ == '__main__':
    launch_gui()
